/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Parking;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author akshay
 */
@WebServlet("/slotbook")
public class SlotBook extends HttpServlet{
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String ad,at,dd,dt;
        
        
        ad=request.getParameter("arrival_date");
        at=request.getParameter("arrival_time");
        dd=request.getParameter("departure_date");      
        dt=request.getParameter("departure_time");
        
        
        request.getSession().setAttribute("ad", ad);
        request.getSession().setAttribute("at", at);
        request.getSession().setAttribute("dd", dd);
        request.getSession().setAttribute("dt", dt);
        
        
        
        response.sendRedirect("color.jsp");
	return;

    }
    
}
